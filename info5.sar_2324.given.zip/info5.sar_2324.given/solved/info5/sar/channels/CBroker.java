package info5.sar.channels;

public class CBroker extends Broker {

  public CBroker(String name) {
    super(name);
    throw new RuntimeException("NYI");
  }

  @Override
  public Channel accept(int port) {
    throw new RuntimeException("NYI");
  }

  @Override
  public Channel connect(String name, int port) {
    throw new RuntimeException("NYI");
  }

}
